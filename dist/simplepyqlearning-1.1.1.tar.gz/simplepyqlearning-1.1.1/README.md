# SimplePyQLearning
A simple python lib to do QLearning
LeLaboDuGame, https://twitch.tv/LeLaboDuGame
See also https://github.com/AdrienDumontet/SimplePyAI
